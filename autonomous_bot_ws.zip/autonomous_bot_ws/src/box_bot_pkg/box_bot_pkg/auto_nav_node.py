#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

class AutoNavNode(Node):
    def __init__(self):
        super().__init__('auto_nav_node')
        self.pub_cmd = self.create_publisher(Twist, '/cmd_vel', 10)
        self.sub_scan = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.get_logger().info("Autonomous Obstacle Avoidance Started!")

    def scan_callback(self, msg):
        ranges = msg.ranges
        num_samples = len(ranges)
        
        # Front 60-degree sector
        front_sector = ranges[int(num_samples*0.4):int(num_samples*0.6)]
        valid_front = [r for r in front_sector if not float('inf') == r and not float('nan') == r]
        
        min_front_dist = min(valid_front) if valid_front else 10.0

        cmd = Twist()
        if min_front_dist < 0.8:
            self.get_logger().warn(f"Obstacle detected ({min_front_dist:.2f}m)! Turning...")
            cmd.linear.x = 0.0
            cmd.angular.z = 0.5
        else:
            cmd.linear.x = 0.3
            cmd.angular.z = 0.0

        self.pub_cmd.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = AutoNavNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()