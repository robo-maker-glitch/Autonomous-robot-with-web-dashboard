#!/usr/bin/env python3
import threading
import json
import time
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, LaserScan
from cv_bridge import CvBridge
from flask import Flask, Response, render_template_string

app = Flask(__name__)
bridge = CvBridge()
latest_frame = None
latest_scan = []
frame_lock = threading.Lock()

class WebBridgeNode(Node):
    def __init__(self):
        super().__init__('web_bridge_node')
        self.create_subscription(Image, '/camera/image_raw', self.img_cb, 1)
        self.create_subscription(LaserScan, '/scan', self.scan_cb, 10)

    def img_cb(self, msg):
        global latest_frame
        try:
            # Resize image to lower bandwidth and latency
            frame = bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            resized = cv2.resize(frame, (480, 360), interpolation=cv2.INTER_NEAREST)
            with frame_lock:
                latest_frame = resized
        except Exception as e:
            pass

    def scan_cb(self, msg):
        global latest_scan
        latest_scan = [min(r, 10.0) if r > 0.1 else 0.0 for r in msg.ranges]

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Robot Realtime Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background: #121212; color: white; text-align: center; }
        .container { display: flex; justify-content: center; gap: 20px; flex-wrap: wrap; margin-top: 20px; }
        .card { background: #1e1e1e; padding: 15px; border-radius: 10px; border: 1px solid #333; }
        canvas { background: #000; border-radius: 5px; }
        img { border-radius: 5px; background: #000; }
    </style>
</head>
<body>
    <h1>🤖 Realtime Box-Bot Dashboard</h1>
    <div class="container">
        <div class="card">
            <h3>Camera Live Stream (Low Latency)</h3>
            <img src="/video_feed" width="480" height="360" />
        </div>
        <div class="card">
            <h3>2D LiDAR Scan Radar</h3>
            <canvas id="lidarCanvas" width="360" height="360"></canvas>
        </div>
    </div>

    <script>
        const canvas = document.getElementById('lidarCanvas');
        const ctx = canvas.getContext('2d');
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;

        function fetchLidar() {
            fetch('/lidar_data')
                .then(res => res.json())
                .then(ranges => {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    
                    ctx.strokeStyle = '#333';
                    for (let r = 40; r <= 160; r += 40) {
                        ctx.beginPath();
                        ctx.arc(centerX, centerY, r, 0, 2 * Math.PI);
                        ctx.stroke();
                    }

                    ctx.fillStyle = '#007acc';
                    ctx.beginPath();
                    ctx.arc(centerX, centerY, 6, 0, 2 * Math.PI);
                    ctx.fill();

                    ctx.fillStyle = '#ffcc00';
                    const angleStep = (2 * Math.PI) / ranges.length;
                    
                    ranges.forEach((dist, i) => {
                        if (dist > 0.1 && dist < 10) {
                            const angle = i * angleStep - Math.PI / 2;
                            const scale = 25;
                            const x = centerX + dist * scale * Math.cos(angle);
                            const y = centerY + dist * scale * Math.sin(angle);
                            
                            ctx.beginPath();
                            ctx.arc(x, y, 2, 0, 2 * Math.PI);
                            ctx.fill();
                        }
                    });
                });
        }
        setInterval(fetchLidar, 100);
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

def generate_frames():
    global latest_frame
    while True:
        with frame_lock:
            if latest_frame is None:
                time.sleep(0.03)
                continue
            ret, buffer = cv2.imencode('.jpg', latest_frame, [int(cv2.IMWRITE_JPEG_QUALITY), 60])
            frame_bytes = buffer.tobytes()

        yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        time.sleep(0.03)  # ~30 FPS lock preventing queue bloat

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/lidar_data')
def lidar_data():
    global latest_scan
    return json.dumps(latest_scan)

def run_ros():
    rclpy.init()
    node = WebBridgeNode()
    rclpy.spin(node)

def main():
    threading.Thread(target=run_ros, daemon=True).start()
    app.run(host='0.0.0.0', port=5000, threaded=True)

if __name__ == '__main__':
    main()