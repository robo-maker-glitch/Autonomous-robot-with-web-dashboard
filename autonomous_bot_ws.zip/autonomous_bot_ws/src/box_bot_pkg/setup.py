import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'box_bot_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='vaishnavi',
    maintainer_email='vaishnavi@todo.todo',
    description='Autonomous Box Bot with Web App Dashboard',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'auto_nav_node = box_bot_pkg.auto_nav_node:main',
            'web_app = box_bot_pkg.web_app:main',
        ],
    },
)